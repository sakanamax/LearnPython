from django.contrib import admin
from ugo.models import urlist
# Register your models here.

admin.site.register(urlist)
