from django.apps import AppConfig


class UgoConfig(AppConfig):
    name = 'ugo'
